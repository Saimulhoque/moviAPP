package com.forbitbd.task.utils;

public class Constant {

    public static final String CATEGORY="CATEGORY";
    public static final String VIDEO_URL="VIDEO_URL";
}
