package com.forbitbd.task.ui.main.popularVideos;


import com.forbitbd.task.model.Movie;

public interface ItemClickListener {
    void onItemClick(Movie movie);

}
