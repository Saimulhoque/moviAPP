package com.forbitbd.task.ui.main.categorie;


import com.forbitbd.task.model.Movie;

public interface MovieClickListener {

    void onMovieClick(Movie movie);
}
